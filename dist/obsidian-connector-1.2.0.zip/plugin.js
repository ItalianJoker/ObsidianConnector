/**
 * Shared helpers for the Obsidian Connector plugin.
 * Used by Node tests (CommonJS) and concatenated into plugin.js / index.html.
 *
 * Linking model: existing Super Productivity project → existing Obsidian page.
 * Opening uses obsidian://open only. This module does not create pages or projects.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.ObsidianConnectorCore = factory();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const STORAGE_VERSION = 3;
  /** Kept in persisted state for older installs; not used by the page-link UI. */
  const DEFAULT_FOLDER = 'Projects';
  const SKIP_VAULT_DIRS = ['.obsidian', '.trash', '.git', 'node_modules'];

  function createEmptyState() {
    return {
      version: STORAGE_VERSION,
      vaultName: '',
      vaultPath: '',
      defaultFolder: DEFAULT_FOLDER,
      bindings: [],
    };
  }

  function getPlatform(api) {
    const platform =
      api && api.cfg && typeof api.cfg.platform === 'string' ? api.cfg.platform : '';
    return platform || 'web';
  }

  function isDesktopPlatform(api) {
    return getPlatform(api) === 'desktop';
  }

  function isMobilePlatform(api) {
    const platform = getPlatform(api);
    return platform === 'android' || platform === 'ios';
  }

  /** True when the host can list vault files via executeNodeScript (desktop only). */
  function canBrowseVault(api) {
    return isDesktopPlatform(api) && typeof (api && api.executeNodeScript) === 'function';
  }

  function isPlainObject(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
  }

  function parseState(raw) {
    const empty = createEmptyState();
    if (raw == null || raw === '') {
      return empty;
    }

    let parsed = raw;
    if (typeof raw === 'string') {
      try {
        parsed = JSON.parse(raw);
      } catch {
        return empty;
      }
    }
    if (!isPlainObject(parsed)) {
      return empty;
    }

    const vaultName = typeof parsed.vaultName === 'string' ? parsed.vaultName.trim() : '';
    const vaultPath = normalizeVaultRootPath(parsed.vaultPath);
    const defaultFolder =
      typeof parsed.defaultFolder === 'string' && parsed.defaultFolder.trim()
        ? normalizeVaultFilePath(parsed.defaultFolder)
        : DEFAULT_FOLDER;

    const bindings = Array.isArray(parsed.bindings)
      ? parsed.bindings.map(normalizeBinding).filter(Boolean)
      : [];

    const byProject = new Map();
    for (const binding of bindings) {
      byProject.set(binding.projectId, binding);
    }

    return {
      version: STORAGE_VERSION,
      vaultName,
      vaultPath,
      defaultFolder,
      bindings: Array.from(byProject.values()),
    };
  }

  function normalizeBinding(binding) {
    if (!isPlainObject(binding)) {
      return null;
    }
    const projectId = typeof binding.projectId === 'string' ? binding.projectId.trim() : '';
    if (!projectId) {
      return null;
    }
    const filePath = notePathFromBinding(binding);
    if (filePath == null) {
      return null;
    }
    const createdAt =
      typeof binding.createdAt === 'number' && Number.isFinite(binding.createdAt)
        ? binding.createdAt
        : Date.now();
    const updatedAt =
      typeof binding.updatedAt === 'number' && Number.isFinite(binding.updatedAt)
        ? binding.updatedAt
        : createdAt;
    return {
      projectId,
      filePath,
      folderPath: isNoteTarget(filePath) ? parentFolderOf(filePath) : filePath,
      createdAt,
      updatedAt,
    };
  }

  function parentFolderOf(filePath) {
    const normalized = normalizeVaultFilePath(filePath);
    if (!normalized) {
      return '';
    }
    const parts = normalized.split('/');
    if (parts.length <= 1) {
      return '';
    }
    parts.pop();
    return parts.join('/');
  }

  /**
   * Vault-relative target for a binding.
   * Prefers an existing note path; keeps legacy folder-only bindings openable.
   */
  function notePathFromBinding(binding) {
    if (!isPlainObject(binding)) {
      return null;
    }
    const rawFile = typeof binding.filePath === 'string' ? binding.filePath : null;
    const rawFolder = typeof binding.folderPath === 'string' ? binding.folderPath : null;

    if (rawFile != null && rawFile.trim()) {
      const filePath = normalizeVaultFilePath(rawFile);
      if (!filePath) {
        return null;
      }
      if (/\.md$/i.test(filePath)) {
        return withMarkdownExtension(filePath);
      }
      const folder = rawFolder != null ? normalizeVaultFilePath(rawFolder) : null;
      // v1.1 stored folder bindings with filePath === folderPath (no .md).
      if (folder != null && folder === filePath) {
        return filePath;
      }
      return withMarkdownExtension(filePath);
    }

    if (rawFolder != null) {
      const folder = normalizeVaultFilePath(rawFolder);
      if (rawFolder.trim() && !folder) {
        return null;
      }
      return folder;
    }
    return null;
  }

  function isNoteTarget(path) {
    return /\.md$/i.test(String(path || ''));
  }

  function bindingTarget(binding) {
    if (!binding) {
      return '';
    }
    const target = notePathFromBinding(binding);
    return target == null ? '' : target;
  }

  /** Absolute path to the vault folder on disk (desktop). Empty if unset. */
  function normalizeVaultRootPath(filePath) {
    if (typeof filePath !== 'string') {
      return '';
    }
    let path = filePath.trim().replace(/\\/g, '/');
    if (!path) {
      return '';
    }
    if (path.startsWith('//')) {
      return '';
    }
    const isWindows = /^[a-zA-Z]:\//.test(path);
    const isPosix = path.startsWith('/');
    if (!isWindows && !isPosix) {
      return '';
    }
    return path.replace(/\/+$/, '');
  }

  function serializeState(state) {
    return JSON.stringify(parseState(state));
  }

  /**
   * Vault-relative path: forward slashes, no leading slash, no `..` segments.
   * Keeps a trailing `.md` when present.
   */
  function normalizeVaultFilePath(filePath) {
    if (typeof filePath !== 'string') {
      return '';
    }
    let path = filePath.trim().replace(/\\/g, '/');
    if (!path) {
      return '';
    }
    if (/^[a-zA-Z]:/.test(path) || path.startsWith('//')) {
      return '';
    }
    path = path.replace(/^\/+/, '');
    const parts = [];
    for (const part of path.split('/')) {
      if (!part || part === '.') {
        continue;
      }
      if (part === '..') {
        return '';
      }
      parts.push(part);
    }
    return parts.join('/');
  }

  function validateFilePath(filePath) {
    const normalized = normalizeVaultFilePath(filePath);
    if (!normalized) {
      return {
        ok: false,
        message: 'Choose an existing page inside the vault (no absolute paths or ..).',
      };
    }
    return { ok: true, path: normalized };
  }

  /** Normalize and require a vault-relative note path (adds .md when missing). */
  function validateExistingNotePath(filePath) {
    const validated = validateFilePath(filePath);
    if (!validated.ok) {
      return validated;
    }
    return { ok: true, path: withMarkdownExtension(validated.path) };
  }

  function stripMarkdownExtension(filePath) {
    return String(filePath || '').replace(/\.md$/i, '');
  }

  function withMarkdownExtension(filePath) {
    const normalized = normalizeVaultFilePath(filePath);
    if (!normalized) {
      return '';
    }
    return /\.md$/i.test(normalized) ? normalized : `${normalized}.md`;
  }

  function wikiLink(filePath) {
    const normalized = normalizeVaultFilePath(filePath);
    if (!normalized) {
      return '';
    }
    return `[[${stripMarkdownExtension(normalized)}]]`;
  }

  function queryString(params) {
    const parts = [];
    for (const [key, value] of Object.entries(params)) {
      if (value == null || value === '') {
        continue;
      }
      parts.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`);
    }
    return parts.join('&');
  }

  /** Build obsidian://open for an existing binding. Never uses obsidian://new. */
  function buildOpenUri(state, binding) {
    if (!binding) {
      return null;
    }
    const target = bindingTarget(binding);
    const vaultName = (state && state.vaultName) || '';
    return `obsidian://open?${queryString({
      vault: vaultName,
      file: stripMarkdownExtension(target),
    })}`;
  }

  function getBinding(state, projectId) {
    if (!state || !projectId) {
      return null;
    }
    return state.bindings.find((binding) => binding.projectId === projectId) || null;
  }

  function upsertBinding(state, projectId, filePath, now) {
    const next = parseState(state);
    if (!projectId) {
      return {
        ok: false,
        state: next,
        message: 'Choose an existing Super Productivity project.',
      };
    }
    const validated = validateExistingNotePath(filePath);
    if (!validated.ok) {
      return { ok: false, state: next, message: validated.message };
    }
    const path = validated.path;
    const timestamp = typeof now === 'number' ? now : Date.now();
    const existing = getBinding(next, projectId);
    const binding = {
      projectId,
      filePath: path,
      folderPath: parentFolderOf(path),
      createdAt: existing ? existing.createdAt : timestamp,
      updatedAt: timestamp,
    };
    next.bindings = next.bindings.filter((item) => item.projectId !== projectId);
    next.bindings.push(binding);
    next.bindings.sort((a, b) => a.filePath.localeCompare(b.filePath));
    return { ok: true, state: next, binding };
  }

  function removeBinding(state, projectId) {
    const next = parseState(state);
    next.bindings = next.bindings.filter((item) => item.projectId !== projectId);
    return next;
  }

  function updateVaultSettings(state, { vaultName, vaultPath, defaultFolder }) {
    const next = parseState(state);
    if (typeof vaultName === 'string') {
      next.vaultName = vaultName.trim();
    }
    if (typeof vaultPath === 'string') {
      next.vaultPath = normalizeVaultRootPath(vaultPath);
    }
    if (typeof defaultFolder === 'string') {
      const folder = normalizeVaultFilePath(defaultFolder);
      next.defaultFolder = folder || DEFAULT_FOLDER;
    }
    return next;
  }

  function rankPath(pathValue, projectTitle) {
    if (!projectTitle) {
      return 0;
    }
    const hay = String(pathValue || '').toLowerCase();
    const title = String(projectTitle).toLowerCase().trim();
    if (!title) {
      return 0;
    }
    const leaf = hay.split('/').pop() || hay;
    if (leaf === title || hay === title) {
      return 5;
    }
    if (leaf.includes(title) || hay.endsWith('/' + title)) {
      return 4;
    }
    if (hay.includes(title)) {
      return 3;
    }
    const words = title.split(/[^a-z0-9]+/i).filter((word) => word.length > 2);
    if (!words.length) {
      return 0;
    }
    const hits = words.filter((word) => hay.includes(word)).length;
    return hits ? 1 + hits / words.length : 0;
  }

  function rankPage(pagePath, projectTitle) {
    return rankPath(stripMarkdownExtension(pagePath), projectTitle);
  }

  /** Filter/search existing pages and rank likely project-name matches first. */
  function filterPages(pages, query, projectTitle) {
    const list = Array.isArray(pages) ? pages.slice() : [];
    const needle = String(query || '').trim().toLowerCase();
    const filtered = needle
      ? list.filter((page) => {
          const path = typeof page === 'string' ? page : page && page.path;
          const name = typeof page === 'string' ? page : page && page.name;
          return (
            String(path || '')
              .toLowerCase()
              .includes(needle) ||
            String(name || '')
              .toLowerCase()
              .includes(needle)
          );
        })
      : list;
    filtered.sort((a, b) => {
      const pathA = typeof a === 'string' ? a : a.path || '';
      const pathB = typeof b === 'string' ? b : b.path || '';
      const rank = rankPage(pathB, projectTitle) - rankPage(pathA, projectTitle);
      if (rank !== 0) {
        return rank;
      }
      return pathA.localeCompare(pathB);
    });
    return filtered;
  }

  /**
   * Node script string for executeNodeScript: list existing .md pages under the vault.
   * Does not create files.
   */
  function listVaultPagesScript(vaultRoot) {
    const root = normalizeVaultRootPath(vaultRoot);
    return `
const fs = require('fs');
const path = require('path');
const root = path.resolve(${JSON.stringify(root)});
if (!root || !fs.existsSync(root) || !fs.statSync(root).isDirectory()) {
  throw new Error('Vault folder not found');
}
const skip = new Set(${JSON.stringify(SKIP_VAULT_DIRS)});
const pages = [];
function walk(dir, rel, depth) {
  if (depth > 10 || pages.length >= 5000) {
    return;
  }
  let names;
  try {
    names = fs.readdirSync(dir);
  } catch (e) {
    return;
  }
  for (const name of names) {
    if (!name || name.charAt(0) === '.' || skip.has(name)) {
      continue;
    }
    const full = path.join(dir, name);
    let st;
    try {
      st = fs.statSync(full);
    } catch (e) {
      continue;
    }
    if (st.isDirectory()) {
      const relative = rel ? rel + '/' + name : name;
      walk(full, relative, depth + 1);
      continue;
    }
    if (!st.isFile() || !/\\.md$/i.test(name)) {
      continue;
    }
    const relative = rel ? rel + '/' + name : name;
    pages.push({
      path: relative.replace(/\\\\/g, '/'),
      name: name.replace(/\\.md$/i, ''),
    });
  }
}
walk(root, '', 0);
return pages;
`;
  }

  /** Parse executeNodeScript results into { ok, pages, error }. */
  function parseNodePageResult(result) {
    if (!result || result.success === false) {
      const error =
        (result && result.error && result.error.message) ||
        (result && result.error) ||
        'Could not read the vault folder.';
      return { ok: false, pages: [], error: String(error) };
    }
    const raw = result.result;
    if (!Array.isArray(raw)) {
      return {
        ok: false,
        pages: [],
        error: 'Unexpected page list from the desktop app.',
      };
    }

    const pages = [];
    for (const item of raw) {
      let pathValue = '';
      let name = '';
      if (typeof item === 'string') {
        pathValue = normalizeVaultFilePath(item);
        name = item.split('/').pop() || item;
      } else if (item && typeof item === 'object') {
        pathValue = normalizeVaultFilePath(item.path || '');
        name =
          typeof item.name === 'string' && item.name
            ? item.name
            : pathValue.split('/').pop() || '';
      } else {
        continue;
      }
      if (!pathValue && !name) {
        continue;
      }
      const notePath = withMarkdownExtension(pathValue || name);
      if (!notePath) {
        continue;
      }
      pages.push({
        path: notePath,
        name: stripMarkdownExtension(name || notePath.split('/').pop() || notePath),
      });
    }
    return { ok: true, pages, error: '' };
  }

  function visibleProjects(projects) {
    return (projects || []).filter(
      (project) => project && !project.isArchived && !project.isHiddenFromMenu,
    );
  }

  function openExternalUri(uri) {
    if (!uri || typeof uri !== 'string') {
      return { ok: false, uri: '', copied: false };
    }
    if (typeof window === 'undefined' || typeof document === 'undefined') {
      return { ok: false, uri, copied: false };
    }

    try {
      const opened = window.open(uri, '_blank');
      if (opened) {
        return { ok: true, uri, copied: false };
      }
    } catch {
      // fall through
    }

    try {
      const anchor = document.createElement('a');
      anchor.href = uri;
      anchor.target = '_blank';
      anchor.rel = 'noopener noreferrer';
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      return { ok: true, uri, copied: false };
    } catch {
      // fall through
    }

    return { ok: false, uri, copied: false };
  }

  async function copyText(text) {
    if (text == null) {
      return false;
    }
    const value = String(text);
    if (
      typeof navigator !== 'undefined' &&
      navigator.clipboard &&
      navigator.clipboard.writeText
    ) {
      try {
        await navigator.clipboard.writeText(value);
        return true;
      } catch {
        // fall through
      }
    }
    if (typeof document === 'undefined') {
      return false;
    }
    try {
      const area = document.createElement('textarea');
      area.value = value;
      area.setAttribute('readonly', '');
      area.style.position = 'fixed';
      area.style.left = '-9999px';
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand('copy');
      area.remove();
      return ok;
    } catch {
      return false;
    }
  }

  function interpolate(template, params) {
    if (template == null) {
      return '';
    }
    const text = String(template);
    if (!params) {
      return text;
    }
    return text.replace(/\{\{(\w+)\}\}/g, (_, name) =>
      params[name] == null ? '' : String(params[name]),
    );
  }

  function t(api, key, fallback, params) {
    try {
      if (api && typeof api.translate === 'function') {
        const translated = api.translate(key, params);
        // iframe translate() can return a Promise — never write that into the DOM.
        if (typeof translated === 'string' && translated && translated !== key) {
          return interpolate(translated, params);
        }
      }
    } catch {
      // English fallback
    }
    return interpolate(fallback || key, params);
  }

  return {
    STORAGE_VERSION,
    DEFAULT_FOLDER,
    SKIP_VAULT_DIRS,
    createEmptyState,
    parseState,
    serializeState,
    normalizeVaultFilePath,
    normalizeVaultRootPath,
    validateFilePath,
    validateExistingNotePath,
    stripMarkdownExtension,
    withMarkdownExtension,
    wikiLink,
    buildOpenUri,
    getBinding,
    bindingTarget,
    notePathFromBinding,
    upsertBinding,
    removeBinding,
    updateVaultSettings,
    visibleProjects,
    filterPages,
    rankPage,
    listVaultPagesScript,
    parseNodePageResult,
    getPlatform,
    isDesktopPlatform,
    isMobilePlatform,
    canBrowseVault,
    isNoteTarget,
    openExternalUri,
    copyText,
    t,
  };
});

/* Host-side Super Productivity plugin. Concatenated after core.js into plugin.js.
 * Registers menu / header / side-panel entry points that open the link panel
 * or an existing linked page via obsidian://open.
 */
(function () {
  'use strict';

  const Core = globalThis.ObsidianConnectorCore;
  const api = globalThis.PluginAPI;

  if (!api || !Core) {
    return;
  }

  function t(key, fallback, params) {
    return Core.t(api, key, fallback, params);
  }

  async function loadState() {
    try {
      const raw = await api.loadSyncedData();
      return Core.parseState(raw);
    } catch {
      return Core.createEmptyState();
    }
  }

  function openPanel() {
    if (typeof api.showIndexHtmlAsView === 'function') {
      api.showIndexHtmlAsView();
    }
  }

  /** Open the connector panel so the user can pick an existing Obsidian page. */
  async function openLinkWindow(context) {
    const ctx =
      context ||
      (typeof api.getActiveWorkContext === 'function'
        ? await api.getActiveWorkContext()
        : null);

    if (ctx && ctx.type === 'PROJECT') {
      api.showSnack({
        msg: t(
          'MSG.OPENING_LINK_WINDOW',
          'Open the Obsidian Connector panel to link "{{title}}" to an existing page.',
          { title: ctx.title || '' },
        ),
        type: 'INFO',
      });
    }
    openPanel();
  }

  /** Open the linked page, or the link panel when the project is not linked yet. */
  async function openLinkedNote(context) {
    const ctx =
      context ||
      (typeof api.getActiveWorkContext === 'function'
        ? await api.getActiveWorkContext()
        : null);

    if (!ctx || ctx.type !== 'PROJECT') {
      api.showSnack({
        msg: t(
          'MSG.NO_PROJECT_CONTEXT',
          'Open a project first, then try again.',
        ),
        type: 'INFO',
      });
      await openLinkWindow();
      return;
    }

    const state = await loadState();
    const binding = Core.getBinding(state, ctx.id);
    if (!binding) {
      api.showSnack({
        msg: t(
          'MSG.PROJECT_NOT_LINKED',
          'This project is not linked to an Obsidian page yet.',
        ),
        type: 'INFO',
      });
      await openLinkWindow(ctx);
      return;
    }

    const uri = Core.buildOpenUri(state, binding);
    const result = Core.openExternalUri(uri);
    if (!result.ok) {
      const copied = await Core.copyText(uri);
      api.showSnack({
        msg: copied
          ? t(
              'MSG.URI_COPIED',
              'Could not open Obsidian automatically. The URI was copied to the clipboard.',
            )
          : t('MSG.OPEN_FAILED', 'Could not open Obsidian. URI: ') + uri,
        type: copied ? 'INFO' : 'ERROR',
      });
      return;
    }

    api.showSnack({
      msg: t('MSG.OPENING_NOTE', 'Opening {{file}} in Obsidian…', {
        file: Core.bindingTarget(binding),
      }),
      type: 'SUCCESS',
      ico: 'menu_book',
    });
  }

  function boot() {
    // SP cannot inject into the project ⋮ work-context menu yet.
    // Supported entry points: plugin menu, header buttons, side panel / Panels.
    try {
      api.registerMenuEntry({
        label: t('MENU.LINK_PAGE', 'Link Obsidian page…'),
        icon: 'menu_book',
        onClick: () => {
          openLinkWindow();
        },
      });
    } catch {
      // Host may already add a default menu entry from the manifest.
    }

    try {
      api.registerMenuEntry({
        label: t('PLUGIN.NAME', 'Obsidian Connector'),
        icon: 'menu_book',
        onClick: openPanel,
      });
    } catch {
      // Ignore duplicate registration.
    }

    if (typeof api.registerConfigHandler === 'function') {
      api.registerConfigHandler(openPanel);
    }

    if (typeof api.registerShortcut === 'function') {
      api.registerShortcut({
        id: 'obsidian-connector-open-note',
        label: t('SHORTCUT.OPEN_LINKED_NOTE', 'Open linked Obsidian page'),
        onExec: () => {
          openLinkedNote();
        },
      });
      api.registerShortcut({
        id: 'obsidian-connector-open-panel',
        label: t('SHORTCUT.OPEN_PANEL', 'Open Obsidian Connector'),
        onExec: openPanel,
      });
      api.registerShortcut({
        id: 'obsidian-connector-link-page',
        label: t('SHORTCUT.LINK_PAGE', 'Link project to Obsidian page'),
        onExec: () => {
          openLinkWindow();
        },
      });
    }

    const headerCfg = {
      label: t('HEADER.OPEN_NOTE', 'Obsidian'),
      icon: 'menu_book',
      onClick: (ctx) => {
        openLinkedNote(ctx);
      },
    };

    if (typeof api.registerWorkContextHeaderButton === 'function') {
      api.registerWorkContextHeaderButton({
        ...headerCfg,
        showFor: ['PROJECT'],
      });
      try {
        api.registerWorkContextHeaderButton({
          label: t('HEADER.LINK_PAGE', 'Link Obsidian'),
          icon: 'link',
          showFor: ['PROJECT'],
          onClick: (ctx) => {
            openLinkWindow(ctx);
          },
        });
      } catch {
        // Older hosts may only allow one work-context header button.
      }
    } else if (typeof api.registerHeaderButton === 'function') {
      api.registerHeaderButton(headerCfg);
    }

    if (typeof api.registerSidePanelButton === 'function') {
      try {
        api.registerSidePanelButton({
          label: t('PLUGIN.NAME', 'Obsidian Connector'),
          icon: 'menu_book',
          onClick: openPanel,
        });
      } catch {
        // Manifest sidePanel may already register one.
      }
    }
  }

  if (typeof api.onReady === 'function') {
    api.onReady(boot);
  } else {
    boot();
  }
})();

